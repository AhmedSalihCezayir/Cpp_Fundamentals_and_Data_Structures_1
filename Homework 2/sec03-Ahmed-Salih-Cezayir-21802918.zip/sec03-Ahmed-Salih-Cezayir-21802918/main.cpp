#include <chrono>
#include <cstdlib>
#include <algorithm>
#include <iostream>
using namespace std;

int* sortAlgorithm1(const int arr1[], const int arr2[], const int size1, const int size2) {
	int* arr3 = new int[size1 + size2];
	int start = 0;
	int last = size1 - 1;

	for (int i = 0; i < size1; i++) {
		arr3[i] = arr1[i];
	}

	for (int i = 0; i < size2; i++) {
		if (arr2[i] >= arr3[last]) {
			last++;
			arr3[last] = arr2[i];
			start = last;
		}
		else {
			for (int k = start; k <= last; k++) {
				if (arr3[k] > arr2[i]) {
					for (int l = last; l >= k; l--) {
						arr3[l + 1] = arr3[l];
					}
					arr3[k] = arr2[i];
					last++;
					start = k + 1;
					break;
				}
			}
		}
	}
	return arr3;
}

//This method works like merge sort's merging part
int* sortAlgorithm2(const int arr1[], const int arr2[], const int size1, const int size2) {
	int* arr3 = new int[size1 + size2];
	int first = 0;
	int second = 0;
	int i = 0;

	while (first < size1 && second < size2) {
		if (arr1[first] < arr2[second]) {
			arr3[i] = arr1[first];
			first++;
		}
		else {
			arr3[i] = arr2[second];
			second++;
		}
		i++;
	}

	//Checking if there any element is left in arr1
	while (first < size1) {
		arr3[i] = arr1[first];
		first++;
		i++;
	}
	//Checking if there any element is left in arr2
	while (second < size2) {
		arr3[i] = arr2[second];
		second++;
		i++;
	}

	return arr3;
}

int main() {
	srand((unsigned)time(0));

	std::chrono::time_point< std::chrono::system_clock > startTime;
	std::chrono::duration< double, milli > elapsedTime;

	const int size1 = 200;
	const int size2 = 400;
	const int size3 = 800;

	int* arr1_1 = new int[size1];
	int* arr1_2 = new int[size1];
	int* arr1_3;
	int* arr1_4;
	
	int* arr2_1 = new int[size2];
	int* arr2_2 = new int[size2];
	int* arr2_3;
	int* arr2_4;
	
	int* arr3_1 = new int[size3];
	int* arr3_2 = new int[size3];
	int* arr3_3;
	int* arr3_4;

	for (int i = 0; i < size1; i++) {
		arr1_1[i] = ((rand() % 20) + 1);
		arr1_2[i] = ((rand() % 20) + 21);
	}
	sort(arr1_1, arr1_1 + size1);
	sort(arr1_2, arr1_2 + size1);

	startTime = std::chrono::system_clock::now();
	arr1_3 = sortAlgorithm1(arr1_1, arr1_2, size1, size1);
	elapsedTime = std::chrono::system_clock::now() - startTime;
	cout << "Execution took " << elapsedTime.count() << " milliseconds. (sortAlgorithm1 / small N / arr1 < arr2)" << endl;

	startTime = std::chrono::system_clock::now();
	arr1_4 = sortAlgorithm2(arr1_1, arr1_2, size1, size1);
	elapsedTime = std::chrono::system_clock::now() - startTime;
	cout << "Execution took " << elapsedTime.count() << " milliseconds. (sortAlgorithm2 / small N / arr1 < arr2)" << endl;
	cout << endl;

	/*
	for (int i = 0; i < size1; i++) {
		cout << arr1_3[i] << " ";
	}

	for (int i = 0; i < size1; i++) {
		cout << arr1_4[i] << " ";
	}
	*/
	delete[] arr1_1;
	delete[] arr1_2;
	delete[] arr1_3;
	delete[] arr1_4;

	//----------------------------------------------------------------------------------------------
	for (int i = 0; i < size2; i++) {
		arr2_1[i] = ((rand() % 20) + 1); 
		arr2_2[i] = ((rand() % 20) + 21);
	}
	sort(arr2_1, arr2_1 + size2);
	sort(arr2_2, arr2_2 + size2);

	startTime = std::chrono::system_clock::now();
	arr2_3 = sortAlgorithm1(arr2_1, arr2_2, size2, size2);
	elapsedTime = std::chrono::system_clock::now() - startTime;
	cout << "Execution took " << elapsedTime.count() << " milliseconds. (sortAlgorithm1 / middle N / arr1 < arr2)" << endl;

	startTime = std::chrono::system_clock::now();
	arr2_4 = sortAlgorithm2(arr2_1, arr2_2, size1, size1);
	elapsedTime = std::chrono::system_clock::now() - startTime;
	cout << "Execution took " << elapsedTime.count() << " milliseconds. (sortAlgorithm2 / middle N / arr1 < arr2)" << endl;
	cout << endl;

	/*
	for (int i = 0; i < size2; i++) {
		cout << arr2_3[i] << " ";
	}

	for (int i = 0; i < size2; i++) {
		cout << arr2_4[i] << " ";
	}
	*/

	delete[] arr2_1;
	delete[] arr2_2;
	delete[] arr2_3;
	delete[] arr2_4;

	//----------------------------------------------------------------------------------------------
	for (int i = 0; i < size3; i++) {
		arr3_1[i] = ((rand() % 20) + 1); 
		arr3_2[i] = ((rand() % 20) + 21);
	}
	sort(arr3_1, arr3_1 + size3);
	sort(arr3_2, arr3_2 + size3);

	startTime = std::chrono::system_clock::now();
	arr3_3 = sortAlgorithm1(arr3_1, arr3_2, size3, size3);
	elapsedTime = std::chrono::system_clock::now() - startTime;
	cout << "Execution took " << elapsedTime.count() << " milliseconds. (sortAlgorithm1 / large N / arr1 < arr2)" << endl;

	startTime = std::chrono::system_clock::now();
	arr3_4 = sortAlgorithm2(arr3_1, arr3_2, size3, size3);
	elapsedTime = std::chrono::system_clock::now() - startTime;
	cout << "Execution took " << elapsedTime.count() << " milliseconds. (sortAlgorithm2 / large N / arr1 < arr2)" << endl;
	cout << endl;

	/*
	for (int i = 0; i < size3; i++) {
		cout << arr3_3[i] << " ";
	}

	for (int i = 0; i < size3; i++) {
		cout << arr3_4[i] << " ";
	}
	*/

	delete[] arr3_1;
	delete[] arr3_2;
	delete[] arr3_3;
	delete[] arr3_4;

	//----------------------------------------------------------------------------------------------
	int* arr4_1 = new int[size1];
	int* arr4_2 = new int[size1];
	int* arr4_3;
	int* arr4_4;

	int* arr5_1 = new int[size2];
	int* arr5_2 = new int[size2];
	int* arr5_3;
	int* arr5_4;

	int* arr6_1 = new int[size3];
	int* arr6_2 = new int[size3];
	int* arr6_3;
	int* arr6_4;

	for (int i = 0; i < size1; i++) {
		arr4_1[i] = ((rand() % 20) + 21);
		arr4_2[i] = ((rand() % 20) + 1);
	}
	sort(arr4_1, arr4_1 + size1);
	sort(arr4_2, arr4_2 + size1);

	startTime = std::chrono::system_clock::now();
	arr4_3 = sortAlgorithm1(arr4_1, arr4_2, size1, size1);
	elapsedTime = std::chrono::system_clock::now() - startTime;
	cout << "Execution took " << elapsedTime.count() << " milliseconds. (sortAlgorithm1 / small N / arr1 > arr2)" << endl;

	startTime = std::chrono::system_clock::now();
	arr4_4 = sortAlgorithm2(arr4_1, arr4_2, size1, size1);
	elapsedTime = std::chrono::system_clock::now() - startTime;
	cout << "Execution took " << elapsedTime.count() << " milliseconds. (sortAlgorithm2 / small N / arr1 > arr2)" << endl;
	cout << endl;

	/*
	for (int i = 0; i < size1; i++) {
		cout << arr4_3[i] << " ";
	}

	for (int i = 0; i < size1; i++) {
		cout << arr4_4[i] << " ";
	}
	*/

	delete[] arr4_1;
	delete[] arr4_2;
	delete[] arr4_3;
	delete[] arr4_4;

	//----------------------------------------------------------------------------------------------
	for (int i = 0; i < size2; i++) {
		arr5_1[i] = ((rand() % 20) + 21);
		arr5_2[i] = ((rand() % 20) + 1);
	}
	sort(arr5_1, arr5_1 + size2);
	sort(arr5_2, arr5_2 + size2);

	startTime = std::chrono::system_clock::now();
	arr5_3 = sortAlgorithm1(arr5_1, arr5_2, size2, size2);
	elapsedTime = std::chrono::system_clock::now() - startTime;
	cout << "Execution took " << elapsedTime.count() << " milliseconds. (sortAlgorithm1 / middle N / arr1 > arr2)" << endl;

	startTime = std::chrono::system_clock::now();
	arr5_4 = sortAlgorithm2(arr5_1, arr5_2, size2, size2);
	elapsedTime = std::chrono::system_clock::now() - startTime;
	cout << "Execution took " << elapsedTime.count() << " milliseconds. (sortAlgorithm2 / middle N / arr1 > arr2)" << endl;
	cout << endl;

	/*
	for (int i = 0; i < size2; i++) {
		cout << arr5_3[i] << " ";
	}

	for (int i = 0; i < size2; i++) {
		cout << arr5_4[i] << " ";
	}
	*/

	delete[] arr5_1;
	delete[] arr5_2;
	delete[] arr5_3;
	delete[] arr5_4;

	//----------------------------------------------------------------------------------------------
	for (int i = 0; i < size3; i++) {
		arr6_1[i] = ((rand() % 20) + 21);
		arr6_2[i] = ((rand() % 20) + 1);
	}
	sort(arr6_1, arr6_1 + size3);
	sort(arr6_2, arr6_2 + size3);

	startTime = std::chrono::system_clock::now();
	arr6_3 = sortAlgorithm1(arr6_1, arr6_2, size3, size3);
	elapsedTime = std::chrono::system_clock::now() - startTime;
	cout << "Execution took " << elapsedTime.count() << " milliseconds. (sortAlgorithm1 / large N / arr1 > arr2)" << endl;

	startTime = std::chrono::system_clock::now();
	arr6_4 = sortAlgorithm2(arr6_1, arr6_2, size3, size3);
	elapsedTime = std::chrono::system_clock::now() - startTime;
	cout << "Execution took " << elapsedTime.count() << " milliseconds. (sortAlgorithm2 / large N / arr1 > arr2)" << endl;
	cout << endl;

	/*
	for (int i = 0; i < size3; i++) {
		cout << arr6_3[i] << " ";
	}

	for (int i = 0; i < size3; i++) {
		cout << arr6_4[i] << " ";
	}
	*/

	delete[] arr6_1;
	delete[] arr6_2;
	delete[] arr6_3;
	delete[] arr6_4;

	//----------------------------------------------------------------------------------------------
	int* arr7_1 = new int[size1];
	int* arr7_2 = new int[size1];
	int* arr7_3;
	int* arr7_4;

	int* arr8_1 = new int[size2];
	int* arr8_2 = new int[size2];
	int* arr8_3;
	int* arr8_4;

	int* arr9_1 = new int[size3];
	int* arr9_2 = new int[size3];
	int* arr9_3;
	int* arr9_4;

	for (int i = 0; i < size1; i++) {
		arr7_1[i] = ((rand() % 40) + 1);
		arr7_2[i] = ((rand() % 40) + 1);
	}
	sort(arr7_1, arr7_1 + size1);
	sort(arr7_2, arr7_2 + size1);

	startTime = std::chrono::system_clock::now();
	arr7_3 = sortAlgorithm1(arr7_1, arr7_2, size1, size1);
	elapsedTime = std::chrono::system_clock::now() - startTime;
	cout << "Execution took " << elapsedTime.count() << " milliseconds. (sortAlgorithm1 / small N / random)" << endl;

	startTime = std::chrono::system_clock::now();
	arr7_4 = sortAlgorithm2(arr7_1, arr7_2, size1, size1);
	elapsedTime = std::chrono::system_clock::now() - startTime;
	cout << "Execution took " << elapsedTime.count() << " milliseconds. (sortAlgorithm2 / small N / random)" << endl;
	cout << endl;

	/*
	for (int i = 0; i < size1; i++) {
		cout << arr7_3[i] << " ";
	}

	for (int i = 0; i < size1; i++) {
		cout << arr7_4[i] << " ";
	}
	*/

	delete[] arr7_1;
	delete[] arr7_2;
	delete[] arr7_3;
	delete[] arr7_4;

	//----------------------------------------------------------------------------------------------
	for (int i = 0; i < size2; i++) {
		arr8_1[i] = ((rand() % 40) + 1);
		arr8_2[i] = ((rand() % 40) + 1);
	}
	sort(arr8_1, arr8_1 + size2);
	sort(arr8_2, arr8_2 + size2);

	startTime = std::chrono::system_clock::now();
	arr8_3 = sortAlgorithm1(arr8_1, arr8_2, size2, size2);
	elapsedTime = std::chrono::system_clock::now() - startTime;
	cout << "Execution took " << elapsedTime.count() << " milliseconds. (sortAlgorithm1 / middle N / random)" << endl;

	startTime = std::chrono::system_clock::now();
	arr8_4 = sortAlgorithm2(arr8_1, arr8_2, size2, size2);
	elapsedTime = std::chrono::system_clock::now() - startTime;
	cout << "Execution took " << elapsedTime.count() << " milliseconds. (sortAlgorithm2 / middle N / random)" << endl;
	cout << endl;

	/*
	for (int i = 0; i < size2; i++) {
		cout << arr8_3[i] << " ";
	}

	for (int i = 0; i < size2; i++) {
		cout << arr8_4[i] << " ";
	}
	*/

	delete[] arr8_1;
	delete[] arr8_2;
	delete[] arr8_3;
	delete[] arr8_4;

	//----------------------------------------------------------------------------------------------
	for (int i = 0; i < size3; i++) {
		arr9_1[i] = ((rand() % 40) + 1);  
		arr9_2[i] = ((rand() % 40) + 1);
	}
	sort(arr9_1, arr9_1 + size3);
	sort(arr9_2, arr9_2 + size3);

	startTime = std::chrono::system_clock::now();
	arr9_3 = sortAlgorithm1(arr9_1, arr9_2, size3, size3);
	elapsedTime = std::chrono::system_clock::now() - startTime;
	cout << "Execution took " << elapsedTime.count() << " milliseconds. (sortAlgorithm1 / large N / random)" << endl;

	startTime = std::chrono::system_clock::now();
	arr9_4 = sortAlgorithm2(arr9_1, arr9_2, size3, size3);
	elapsedTime = std::chrono::system_clock::now() - startTime;
	cout << "Execution took " << elapsedTime.count() << " milliseconds. (sortAlgorithm2 / large N / random)" << endl;
	cout << endl;

	/*
	for (int i = 0; i < size3; i++) {
		cout << arr9_3[i] << " ";
	}

	for (int i = 0; i < size3; i++) {
		cout << arr9_4[i] << " ";
	}
	*/

	delete[] arr9_1;
	delete[] arr9_2;
	delete[] arr9_3;
	delete[] arr9_4;
}
